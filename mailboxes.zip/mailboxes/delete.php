<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Connect to the database (Replace with your database credentials)
    $conn = new mysqli("localhost", "username", "password", "database");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Delete lecturer from the database
    $sql = "DELETE FROM lecturers WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header('Location: home.php');
    } else {
        echo "Error deleting lecturer: " . $conn->error;
    }

    $conn->close();
}
?>
