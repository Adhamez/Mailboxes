<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Connect to the database (Replace with your database credentials)
    $conn = new mysqli("localhost", "username", "password", "database");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM lecturers WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        echo "Lecturer not found.";
        exit;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Lecturer</title>
</head>
<body>
    <h2>Edit Lecturer</h2>
    <form method="post" action="update.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        Lecturer Name: <input type="text" name="lecturer_name" value="<?php echo $row['lecturer_name']; ?>"><br>
        Mailbox Number: <input type="number" name="mailbox_number" value="<?php echo $row['mailbox_number']; ?>"><br>
        Phone Number: <input type="text" name="phone_number" value="<?php echo $row['phone_number']; ?>"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>
