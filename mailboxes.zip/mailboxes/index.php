<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="post" action="login.php">
        Password: <input type="password" name="password">
        <input type="submit" value="Login">
    </form>
</body>
</html>
