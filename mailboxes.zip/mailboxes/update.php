<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Connect to the database (Replace with your database credentials)
    $conn = new mysqli("localhost", "username", "password", "database");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = $_POST['id'];
    $lecturer_name = $_POST['lecturer_name'];
    $mailbox_number = $_POST['mailbox_number'];
    $phone_number = $_POST['phone_number'];

    // Sanitize user input
    $lecturer_name = mysqli_real_escape_string($conn, $lecturer_name);
    $mailbox_number = mysqli_real_escape_string($conn, $mailbox_number);
    $phone_number = mysqli_real_escape_string($conn, $phone_number);

    // Update lecturer in the database
    $sql = "UPDATE lecturers
            SET lecturer_name = '$lecturer_name', mailbox_number = '$mailbox_number', phone_number = '$phone_number'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header('Location: home.php');
    } else {
        echo "Error updating lecturer: " . $conn->error;
    }

    $conn->close();
}
?>
