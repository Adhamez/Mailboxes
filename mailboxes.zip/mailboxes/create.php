<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Connect to the database (Replace with your database credentials)
    $conn = new mysqli("localhost", "username", "password", "database");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $lecturer_name = $_POST['lecturer_name'];
    $mailbox_number = $_POST['mailbox_number'];
    $phone_number = $_POST['phone_number'];

    // Sanitize user input
    $lecturer_name = mysqli_real_escape_string($conn, $lecturer_name);
    $mailbox_number = mysqli_real_escape_string($conn, $mailbox_number);
    $phone_number = mysqli_real_escape_string($conn, $phone_number);

    // Insert lecturer into the database
    $sql = "INSERT INTO lecturers (lecturer_name, mailbox_number, phone_number)
            VALUES ('$lecturer_name', '$mailbox_number', '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        header('Location: home.php');
    } else {
        echo "Error creating lecturer: " . $conn->error;
    }

    $conn->close();
}
?>
