<?php
session_start();
if(isset($_POST['password']) && $_POST['password'] === "AAA"){
    $_SESSION['authenticated'] = true;
    header('Location: home.php');
    exit;
} else {
    echo "Incorrect password. Please try again.";
}
?>
