<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mailbox Management</title>
</head>
<body>
    <h2>Mailbox Management</h2>
    <h3>Create New Lecturer</h3>
    <form method="post" action="create.php">
        Lecturer Name: <input type="text" name="lecturer_name"><br>
        Mailbox Number: <input type="number" name="mailbox_number"><br>
        Phone Number: <input type="text" name="phone_number"><br>
        <input type="submit" value="Create">
    </form>
    <h3>Lecturer List</h3>
    <table>
        <tr>
            <th>Lecturer Name</th>
            <th>Mailbox Number</th>
            <th>Phone Number</th>
            <th>Actions</th>
        </tr>
        <?php
        // Connect to the database (Replace with your database credentials)
        $conn = new mysqli("localhost", "username", "password", "database");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM lecturers";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['lecturer_name'] . "</td>";
                echo "<td>" . $row['mailbox_number'] . "</td>";
                echo "<td>" . $row['phone_number'] . "</td>";
                echo "<td><a href='edit.php?id=" . $row['id'] . "'>Edit</a> | <a href='delete.php?id=" . $row['id'] . "'>Delete</a></td>";
                echo "</tr>";
            }
        }

        $conn->close();
        ?>
    </table>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mailbox Management</title>
</head>
<body>
    <h2>Mailbox Management</h2>
    <h3>Create New Lecturer</h3>
    <form method="post" action="create.php">
        Lecturer Name: <input type="text" name="lecturer_name"><br>
        Mailbox Number: <input type="number" name="mailbox_number"><br>
        Phone Number: <input type="text" name="phone_number"><br>
        <input type="submit" value="Create">
    </form>
    <h3>Lecturer List</h3>
    <table>
        <tr>
            <th>Lecturer Name</th>
            <th>Mailbox Number</th>
            <th>Phone Number</th>
            <th>Actions</th>
        </tr>
        <?php
        // Connect to the database (Replace with your database credentials)
        $conn = new mysqli("localhost", "username", "password", "database");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM lecturers";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['lecturer_name'] . "</td>";
                echo "<td>" . $row['mailbox_number'] . "</td>";
                echo "<td>" . $row['phone_number'] . "</td>";
                echo "<td><a href='edit.php?id=" . $row['id'] . "'>Edit</a> | <a href='delete.php?id=" . $row['id'] . "'>Delete</a></td>";
                echo "</tr>";
            }
        }

        $conn->close();
        ?>
    </table>
</body>
</html>
